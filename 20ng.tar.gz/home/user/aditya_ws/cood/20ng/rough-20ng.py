

# 1]:

#import os
#os.environ["CUDA_VISIBLE_DEVICES"]="1"


# 2]:

import json
import wandb
import os
import glob

import numpy as np
np.random.seed(1)

import keras
# print keras.__version__ #version 2.1.2
from keras import preprocessing


# 3]:
ALL_SUBSETS = ('alt.atheism', 'comp.graphics', 'comp.os.ms-windows.misc', 'comp.sys.ibm.pc.hardware', 'comp.sys.mac.hardware', 'comp.windows.x', 'misc.forsale', 'rec.autos', 'rec.motorcycles', 'rec.sport.baseball', 'rec.sport.hockey', 'sci.crypt', 'sci.electronics', 'sci.med', 'sci.space', 'soc.religion.christian', 'talk.politics.guns', 'talk.politics.mideast', 'talk.politics.misc', 'talk.religion.misc')

def readfile(filepath):
    with open(filepath, 'rb') as file:
        data = str(file.read()).replace('\\n', ' ').replace('\\r', ' ')
    return data

def get_all_20ng(basepath):
    X = []
    y = []
    for subset_idx, subset in enumerate(ALL_SUBSETS):
        subset_globstr = os.path.join(basepath, subset, "*")
        all_files = glob.glob(subset_globstr)
        for filepath in all_files:
            X.append(readfile(filepath))
            y.append(subset_idx)
    return X, y

X, y = get_all_20ng("/home/user/aditya_ws/cood/20ng")
print(X[:5])
print(y[:5])